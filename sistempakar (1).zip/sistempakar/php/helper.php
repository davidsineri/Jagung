<?php
/**
 * =========================================
 * HELPER SISTEM PAKAR JAGUNG (CF)
 * =========================================
 * SATU-SATUNYA sumber rule & CF
 * Dipakai oleh:
 * - diagnosa.php
 * - admin/kelola-rule.php
 * - admin/add-rule.php
 * - admin/edit-rule.php
 */

/**
 * DAFTAR GEJALA
 */
function getGejala()
{
    return [
        'K1' => 'Sering terjadi kemarau',
        'K2' => 'Terdapat penyakit daun',
        'K3' => 'Terdapat penyakit batang',
        'K4' => 'Terdapat penyakit tongkol jagung',
        'K5' => 'Jangka waktu masa tanam > 110 hari',
        'K6' => 'Terdapat hama serangga',
        'K7' => 'Terdapat gulma'
    ];
}

/**
 * BASIS PENGETAHUAN – RULE & CF
 */
function getRulesCF()
{
    return [
        [
            'kode' => 'P98125V',
            'nama_bibit' => 'P98125V',
            'cf_rule' => [
                'K1' => 0.9,
                'K7' => 0.8
            ],
            'tips' => 'Cocok untuk daerah kering dan tahan herbisida.'
        ],
        [
            'kode' => 'P13050V',
            'nama_bibit' => 'P13050V',
            'cf_rule' => [
                'K1' => 0.9,
                'K5' => 0.8
            ],
            'tips' => 'Baik untuk kemarau dengan masa tanam panjang.'
        ],
        [
            'kode' => 'P0075',
            'nama_bibit' => 'P0075',
            'cf_rule' => [
                'K1' => 0.8,
                'K2' => 0.8
            ],
            'tips' => 'Adaptif di lahan kering dan tahan penyakit daun.'
        ],
        [
            'kode' => 'P1108WXQ',
            'nama_bibit' => 'P1108WXQ',
            'cf_rule' => [
                'K4' => 0.9,
                'K5' => 0.8
            ],
            'tips' => 'Tongkol sehat dan hasil panen tinggi.'
        ],
        [
            'kode' => 'P04511V',
            'nama_bibit' => 'P04511V',
            'cf_rule' => [
                'K3' => 0.8,
                'K7' => 0.7
            ],
            'tips' => 'Batang kuat dan tahan herbisida.'
        ],
        [
            'kode' => 'P0075AM',
            'nama_bibit' => 'P0075AM',
            'cf_rule' => [
                'K1' => 0.8,
                'K6' => 0.9
            ],
            'tips' => 'Tahan hama serangga dan cocok di lahan panas.'
        ],
        [
            'kode' => 'P04511AM',
            'nama_bibit' => 'P04511AM',
            'cf_rule' => [
                'K4' => 0.8,
                'K6' => 0.8
            ],
            'tips' => 'Tahan penyakit tongkol dan serangan hama.'
        ],
        [
            'kode' => 'P1742Q',
            'nama_bibit' => 'P1742Q',
            'cf_rule' => [
                'K5' => 0.9,
                'K6' => 0.8
            ],
            'tips' => 'Masa tanam panjang dan tahan hama.'
        ],
        [
            'kode' => 'P12065Q',
            'nama_bibit' => 'P12065Q',
            'cf_rule' => [
                'K4' => 0.9,
                'K5' => 0.9,
                'K6' => 0.9
            ],
            'tips' => 'Cocok untuk daerah lembap dengan ketahanan tinggi.'
        ]
    ];
}

/**
 * RUMUS COMBINE CF (MYCIN)
 */
function combineCF($cf1, $cf2)
{
    return $cf1 + ($cf2 * (1 - $cf1));
}

/**
 * MESIN DIAGNOSA CERTAINTY FACTOR
 */
function diagnosaCF(array $input_user)
{
    $rules = getRulesCF();
    $hasil = [];

    foreach ($rules as $rule) {
        $cf_total = 0;
        $first = true;

        foreach ($rule['cf_rule'] as $kode_gejala => $cf_rule) {

            if (!isset($input_user[$kode_gejala])) {
                continue;
            }

            $cf_user = (float)$input_user[$kode_gejala];
            $cf_gejala = $cf_user * $cf_rule;

            if ($first) {
                $cf_total = $cf_gejala;
                $first = false;
            } else {
                $cf_total = combineCF($cf_total, $cf_gejala);
            }
        }

        if ($cf_total > 0) {
            $hasil[] = [
                'kode' => $rule['kode'],
                'nama_bibit' => $rule['nama_bibit'],
                'cf_persen' => round($cf_total * 100, 2),
                'tips' => $rule['tips']
            ];
        }
    }

    // Urutkan dari CF tertinggi
    usort($hasil, fn($a, $b) => $b['cf_persen'] <=> $a['cf_persen']);

    return $hasil;
}
