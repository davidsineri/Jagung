<?php
session_start();
require_once 'php/helper.php';
require_once 'config.php';

// GUARD LOGIN
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

// Buat token CSRF jika belum ada
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Nama user dari login
$nama_user = htmlspecialchars($_SESSION['username'] ?? 'Pengguna');

// Mapping gejala
$gejala = [
    'K1' => 'Sering terjadi kemarau',
    'K2' => 'Terdapat penyakit daun',
    'K3' => 'Terdapat penyakit batang',
    'K4' => 'Terdapat penyakit tongkol jagung',
    'K5' => 'Jangka waktu masa tanam > 110 hari',
    'K6' => 'Terdapat hama serangga',
    'K7' => 'Terdapat gulma'
];

// Skala CF
$opsi_cf = [
    '1.0' => 'Sangat Yakin',
    '0.8' => 'Yakin',
    '0.6' => 'Cukup Yakin',
    '0.4' => 'Ragu',
    '0.0' => 'Tidak Yakin'
];

$hasil = [];
$input_user = [];
$sukses_simpan = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token tidak valid. Silakan ulangi proses.");
    }

    // Ambil input user
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'cf_') === 0) {
            $kode = str_replace('cf_', '', $key);
            $input_user[$kode] = htmlspecialchars($value);
        }
    }

    // Jalankan sistem pakar CF
    $hasil = diagnosaCF($input_user);

    // Simpan hasil terbaik ke database
    if (!empty($hasil)) {
        $top = $hasil[0];

        $stmt = $conn->prepare("
            INSERT INTO diagnosa_user 
(username, tanggal, hasil_bibit, cf_total, tips)
VALUES (?, NOW(), ?, ?, ?)

        ");
        if ($stmt) {
            $cf_total = $top['cf_persen'] / 100; // NORMALISASI KE 0–1

$stmt->bind_param(
    "ssds",
    $_SESSION['username'],
    $top['nama_bibit'],
    $cf_total,
    $top['tips']
);

            if ($stmt->execute()) {
                $sukses_simpan = true;
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistem Pakar Bibit Jagung</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: 
              linear-gradient(rgba(30, 126, 52, 0.75), rgba(30, 126, 52, 0.75)),
              url('img/diganosa.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }
        html { font-size: 16px; }
    </style>
    <?php if ($sukses_simpan): ?>
    if ($stmt->execute()) {
    header("Location: dashboard.php?success=1");
    exit;
}

    <?php endif; ?>
</head>
<body>

<div class="container my-4" style="max-width: 900px;">
<div class="overlay">

<!-- JUDUL -->
<div class="card mb-3 shadow-sm">
    <div class="card-body text-center">
        <h2 class="fw-bold mb-2">Sistem Pakar Pemilihan Bibit Jagung</h2>
        <p class="text-muted mb-0">Metode Certainty Factor</p>
    </div>
</div>

<!-- FORM DIAGNOSA -->
<div class="card mb-3 shadow-sm">
    <div class="card-header bg-success text-white">
        <strong>Form Diagnosa Kondisi Lahan</strong>
    </div>
    <div class="card-body">
        <form method="post">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <?php foreach ($gejala as $kode => $pertanyaan): ?>
            <div class="mb-3">
                <label class="fw-semibold d-block mb-2"><?= $pertanyaan ?></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php foreach ($opsi_cf as $nilai => $label): ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input"
                                   type="radio"
                                   name="cf_<?= $kode ?>"
                                   value="<?= $nilai ?>"
                                   required>
                            <label class="form-check-label"><?= $label ?></label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <button type="submit" class="btn btn-success btn-lg">
            Proses Diagnosa
        </button>
        </form>
    </div>
</div>

<?php if (!empty($hasil)): ?>

<!-- NOTIFIKASI -->
<?php if ($sukses_simpan): ?>
<div class="alert alert-success text-center">
  ✅ Diagnosa berhasil disimpan ke riwayat. Anda akan diarahkan ke dashboard dalam 5 detik...
</div>
<?php endif; ?>

<!-- IDENTITAS USER -->
<div class="card mb-3">
    <div class="card-body">
        <strong>Nama Petani:</strong> <?= $nama_user ?><br>
        <strong>Tanggal Diagnosa:</strong> <?= date('d-m-Y H:i') ?>
    </div>
</div>

<!-- INPUT USER -->
<div class="card mb-3">
    <div class="card-header bg-secondary text-white">
        <strong>Input Keyakinan Pengguna</strong>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-bordered text-center align-middle">
            <thead class="table-light">
                <tr>
                    <th>Gejala</th>
                    <th>Tingkat Keyakinan</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($gejala as $kode => $nama): ?>
                <?php if (isset($input_user[$kode])): ?>
                <tr>
                    <td><?= $nama ?></td>
                    <td><?= $opsi_cf[$input_user[$kode]] ?></td>
                </tr>
                <?php endif; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- HASIL DIAGNOSA -->
<div class="card shadow-sm mb-3">
    <div class="card-header bg-primary text-white">
        <strong>Hasil Diagnosa</strong>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-bordered text-center align-middle">
            <thead class="table-success">
                <tr>
                    <th>No</th>
                    <th>Nama Bibit Jagung</th>
                    <th>Nilai CF (%)</th>
                    <th>Rekomendasi</th>
                </tr>
            </thead>
            <tbody>
            <?php $no=1; foreach ($hasil as $row): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['nama_bibit']) ?></td>
                    <td><strong><?= htmlspecialchars($row['cf_persen']) ?>%</strong></td>
                    <td><?= htmlspecialchars($row['tips']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <small class="text-muted">
            Catatan: Hasil diagnosis merupakan rekomendasi berdasarkan tingkat keyakinan sistem
            dan tidak bersifat mutlak.
        </small>
    </div>
</div>

<?php endif; ?>

<!-- TOMBOL KEMBALI -->
<div class="text-center mt-4">
  <a href="dashboard.php" class="btn btn-secondary btn-lg">⬅️ Kembali ke Beranda</a>
</div>

</div> <!-- overlay -->
</div> <!-- container -->
</body>
</html>