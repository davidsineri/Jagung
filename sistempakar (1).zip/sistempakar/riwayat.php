<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'config.php';

$username = $_SESSION['username'];

$stmt = $conn->prepare("
  SELECT tanggal, hasil_bibit, cf_total, tips
  FROM diagnosa_user
  WHERE username = ?
  ORDER BY tanggal DESC
  LIMIT 10
");

$stmt->bind_param("s", $username);
$stmt->execute();
$riwayat = $stmt->get_result();
?>

<table class="table table-bordered text-center">
  <thead>
    <tr>
      <th>Tanggal</th>
      <th>Bibit</th>
      <th>CF (%)</th>
      <th>Tips</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($riwayat->num_rows > 0): ?>
      <?php while ($r = $riwayat->fetch_assoc()): ?>
      <tr>
        <td><?= date('d-m-Y H:i', strtotime($r['tanggal'])) ?></td>
        <td><?= htmlspecialchars($r['hasil_bibit']) ?></td>
        <td><?= round($r['cf_total'] * 100, 2) ?>%</td>
        <td><?= htmlspecialchars($r['tips']) ?></td>
      </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="4">Belum ada riwayat</td></tr>
    <?php endif; ?>
  </tbody>
</table>
