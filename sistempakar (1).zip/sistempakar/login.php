<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login - Sistem Pakar Bibit Jagung</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  
<style>
html, body {
  height: 100%;
  margin: 0;
}

body {
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background:
    linear-gradient(rgba(0, 0, 0, 0.45), rgba(0, 0, 0, 0.45)),
    url('img/bg-login.jpg') no-repeat center center fixed;
  background-size: cover;
}

/* CARD LOGIN */
.login-card {
  background: rgba(255, 255, 255, 0.97);
  backdrop-filter: blur(6px);
  border-radius: 16px;
  box-shadow: 0 15px 40px rgba(0,0,0,0.25);
  padding: 1.5rem 1.5rem;   /* 🔽 padding lebih kecil */
  width: 100%;
  max-width: 340px;         /* 🔽 ukuran card lebih kecil */
  text-align: center;
}

/* RESPONSIF MOBILE */
@media (max-width: 576px) {
  .login-card {
    padding: 1.2rem;
    max-width: 90%;
  }

  .login-card h3 {
    font-size: 1.5rem;
  }

  .login-card p {
    font-size: 0.85rem;
  }
}

/* JUDUL */
.login-card h3 {
  color: #2e7d32;
  font-weight: 700;
  margin-bottom: 0.25rem;
  font-size: 1.6rem;   /* 🔽 font judul lebih kecil */
}

.login-card p {
  font-size: 0.9rem;
}

/* FORM */
.form-label {
  font-size: 0.85rem;
  font-weight: 600;
  text-align: left;
  display: block;
}

.form-control {
  border-radius: 10px;
  font-size: 0.85rem;
  padding: 0.5rem 0.6rem;
}

/* BUTTON */
.btn-success, .btn-outline-success {
  border-radius: 20px;
  font-weight: 600;
  font-size: 0.9rem;
  padding: 0.5rem;
}

/* TAB */
.nav-pills .nav-link {
  border-radius: 16px;
  font-weight: 600;
  font-size: 0.85rem;
  padding: 0.35rem 0.8rem;
}

.nav-pills .nav-link.active {
  background-color: #2e7d32;
}
</style>
</head>
<body>

<div class="login-card">

  <div class="text-center mb-4">
    <div style="font-size:5rem;">🌽</div>
    <h3>Sistem Pakar Jagung</h3>
    <p class="text-muted mb-0">Login & Registrasi Petani</p>
  </div>

  <!-- ALERT ERROR -->
  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger py-2">
      <?= $_SESSION['error']; unset($_SESSION['error']); ?>
    </div>
  <?php endif; ?>

  <!-- ALERT SUCCESS -->
  <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success py-2">
      <?= $_SESSION['success']; unset($_SESSION['success']); ?>
    </div>
  <?php endif; ?>

  <!-- TAB LOGIN / REGISTER -->
  <ul class="nav nav-pills mb-4 justify-content-center">
    <li class="nav-item">
      <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#login">
        Login
      </button>
    </li>
    <li class="nav-item">
      <button class="nav-link" data-bs-toggle="pill" data-bs-target="#register">
        Daftar
      </button>
    </li>
  </ul>

  <div class="tab-content">

    <!-- LOGIN -->
    <div class="tab-pane fade show active" id="login">
      <form action="auth/login-proses.php" method="POST">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-4">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success w-100">
          Masuk
        </button>
      </form>
    </div>

    <!-- REGISTER -->
    <div class="tab-pane fade" id="register">
      <form action="auth/register-proses.php" method="POST">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-4">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-outline-success w-100">
          Daftar Akun
        </button>
      </form>
    </div>

  </div>

  <hr>
  <p class="text-center text-muted mb-0" style="font-size: 0.9rem;">
    © 2025 Sistem Pakar Bibit Jagung
  </p>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>