<?php
include 'php/helper.php';
$hasil = diagnosa($_POST);
$rekomendasi = $hasil['rekomendasi'];
$total_cf_input = $hasil['total_cf_input'];
$namaGejala = getNamaGejala();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Hasil Diagnosa Bibit Jagung</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
  <div class="card shadow mx-auto" style="max-width: 850px;">
    <div class="card-header bg-success text-white">
      <h4>🌽 Hasil Rekomendasi Bibit Jagung</h4>
    </div>

    <div class="card-body">

      <div class="alert alert-secondary">
        <strong>🔎 Tingkat Keyakinan Jawaban Anda:</strong>
        <?= number_format($total_cf_input * 100, 1) ?>%
      </div>

      <?php if (empty($rekomendasi)): ?>
        <div class="alert alert-warning">
          Tidak ditemukan varietas yang sesuai.
        </div>
      <?php else: ?>
        <?php foreach ($rekomendasi as $r): ?>
          <div class="border rounded p-3 mb-3">
            <h5>
              <?= htmlspecialchars($r['bibit']) ?>
              <span class="badge bg-primary"><?= $r['kode'] ?></span>
            </h5>

            <p><strong>Alasan:</strong> <?= $r['alasan'] ?></p>

            <p><strong>Gejala Cocok:</strong>
              <?php
              foreach ($r['gejala_cocok'] as $g) {
                  echo "<span class='badge bg-success me-1'>{$namaGejala[$g]}</span>";
              }
              ?>
            </p>

            <div class="mb-2">
              <strong>Tingkat Keyakinan Sistem:</strong>
              <?= number_format($r['cf_final'] * 100, 1) ?>%
              <div class="progress mt-1">
                <div class="progress-bar bg-success"
                     style="width: <?= $r['cf_final'] * 100 ?>%">
                </div>
              </div>
            </div>

            <div class="alert alert-info mb-0">
              <strong>Tips:</strong> <?= $r['tips'] ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>

      <hr>

      <h6>📋 Ringkasan Gejala Anda:</h6>
      <ul class="list-group list-group-flush mb-4">
        <?php foreach ($namaGejala as $kode => $nama): ?>
          <li class="list-group-item">
            <?= $nama ?> :
            <strong><?= ucfirst($_POST['gejala_'.$kode] ?? '-') ?></strong>
          </li>
        <?php endforeach; ?>
      </ul>

      <div class="text-center">
        <a href="diagnosa.php" class="btn btn-outline-secondary">🔄 Ulangi</a>
        <a href="index.html" class="btn btn-success">🏠 Beranda</a>
      </div>

    </div>
  </div>
</div>

</body>
</html>
