<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tentang Kami - Sistem Pakar Bibit Jagung</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .header {
      background: linear-gradient(135deg, #28a745, #218838);
      color: white;
      padding: 3rem 1rem;
      border-radius: 0 0 30px 30px;
      text-align: center;
      margin-bottom: 3rem;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .card-profile {
      border: none;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      background: white;
    }
    .card-profile:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 20px rgba(0,0,0,0.15);
    }
    .profile-img {
      border-radius: 50%;
      width: 100px;
      height: 100px;
      object-fit: cover;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <div class="header">
    <h1>🌽 Tentang Kami</h1>
    <p>Sistem Pakar Rekomendasi Bibit Jagung</p>
  </div>

  <div class="container">
    <!-- Profil Dosen Pembimbing -->
    <section class="mb-5 text-center">
      <h3 class="mb-4 text-success">🎓 Dosen Pembimbing</h3>
      <div class="card card-profile mx-auto p-4" style="max-width:500px;">
        <<img src="https://cdn-icons-png.flaticon.com/512/2922/2922561.png" class="profile-img mx-auto" alt="Dosen">

        <h5 class="mt-2">Yumarlin MZ, S.Kom., M.Pd., M.Kom.</h5>
        <p class="text-muted mb-0">Dosen Pembimbing</p>
        <p>Program Studi Informatika<br>Universitas Janabadra</p>
      </div>
    </section>

    <!-- Profil Mahasiswa -->
    <section class="mb-5">
      <h3 class="mb-4 text-success text-center">👨‍💻 Tim Pengembang</h3>
      <div class="row justify-content-center">

        <div class="col-md-4 mb-4">
          <div class="card card-profile text-center p-4">
            <img src="https://cdn-icons-png.flaticon.com/512/4333/4333609.png" class="profile-img mx-auto" alt="Yudhantama">
            <h5>Yudhantama Pratyahara Gunawan</h5>
            <p class="text-muted">NIM: 24330040</p>
            <p>Mahasiswa Universitas Janabadra<br>Pengembang Sistem Pakar Bibit Jagung</p>
          </div>
        </div>

        <div class="col-md-4 mb-4">
          <div class="card card-profile text-center p-4">
            <img src="https://cdn-icons-png.flaticon.com/512/4333/4333609.png" class="profile-img mx-auto" alt="David">
            <h5>David Yehuda Sineri</h5>
            <p class="text-muted">NIM: 21330053</p>
            <p>Mahasiswa Universitas Janabadra<br>Pengembang Sistem Pakar Bibit Jagung</p>
          </div>
        </div>

      </div>
    </section>

    <!-- Tombol kembali -->
    <div class="text-center my-5">
      <a href="dashboard.php" class="btn btn-outline-success px-4 py-2">&larr; Kembali ke Beranda</a>
    </div>
  </div>

</body>
</html>
