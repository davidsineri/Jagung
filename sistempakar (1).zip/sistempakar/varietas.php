<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Varietas Jagung - Sistem Pakar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: url('img/varieatas.jpg') no-repeat center center fixed;
      background-size: cover;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    h1 {
      color: #28a745;
      text-align: center;
      margin: 40px 0;
    }
    table {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    table th {
      background: #28a745;
      color: white;
      text-align: center;
    }
    table td {
      vertical-align: middle;
    }
    .varietas-img {
      width: 200px;
      height: 150px;
      object-fit: cover;
      border-radius: 8px;
    }
    .btn-back {
      display: block;
      margin: 40px auto;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="container">
  <h1>🌽 Daftar Varietas Jagung</h1>

  <table class="table table-bordered align-middle text-center">
    <thead>
      <tr>
        <th>No</th>
        <th>Gambar</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $varietas = [
      "P98125V" => [
        "deskripsi" => "Bibit varian ini memiliki kelebihan dimana dia memiliki ketahanan yang bagus terhadap cuaca kemarau dan varian ini juga memiliki ketahanan terhadap herbisida. Namun varian ini tidak tahan terhadap penyakit daun, batang maupun tongkol.",
        "gambar" => "images/varietas/P98125V.jpg"
      ],
      "P13050V" => [
        "deskripsi" => "Varietas ini tahan kemarau dan berumur panjang (lebih dari 110 hari), hasil panen tinggi namun tidak tahan terhadap penyakit daun dan tongkol.",
        "gambar" => "images/varietas/P13050V.jpg"
      ],
      "P0075" => [
        "deskripsi" => "P0075 memiliki daya adaptasi tinggi di lahan kering dan tahan penyakit daun, tetapi lemah terhadap penyakit batang dan tongkol.",
        "gambar" => "images/varietas/P0075.jpg"
      ],
      "P1108WXQ" => [
        "deskripsi" => "Varietas ini unggul dalam ketahanan penyakit tongkol dan kualitas biji, namun sangat rentan terhadap penyakit batang.",
        "gambar" => "images/varietas/P1108WXQ.jpg"
      ],
      "P04511V" => [
        "deskripsi" => "P04511V memiliki batang kuat dan tahan herbisida, tetapi mudah terserang penyakit daun dan tongkol.",
        "gambar" => "images/varietas/P04511V.jpg"
      ],
      "P0075AM" => [
        "deskripsi" => "P0075AM cocok untuk lahan kering dan tahan kemarau, namun rentan terhadap penyakit daun dan batang.",
        "gambar" => "images/varietas/P0075AM.jpg"
      ],
      "P04511AM" => [
        "deskripsi" => "P04511AM tahan terhadap batang roboh dan hama serangga, namun lemah terhadap penyakit daun dan tongkol.",
        "gambar" => "images/varietas/P04511AM.jpg"
      ],
      "P1742Q" => [
        "deskripsi" => "P1742Q memiliki masa tumbuh panjang dan hasil tinggi bila dirawat baik, namun kurang tahan terhadap penyakit daun dan tongkol.",
        "gambar" => "images/varietas/P1742Q.jpg"
      ],
      "P12065Q" => [
        "deskripsi" => "P12065Q menghasilkan tongkol besar dan tahan hama, tetapi tidak cocok untuk lahan basah dan rawan penyakit daun.",
        "gambar" => "images/varietas/P12065Q.jpg"
      ]
    ];

    $no = 1;
    foreach ($varietas as $nama => $data) {
        echo "
        <tr>
          <td>$no</td>
          <td><img src='{$data['gambar']}' alt='Varietas $nama' class='varietas-img'></td>
          <td><strong>$nama</strong><br>{$data['deskripsi']}</td>
        </tr>
        ";
        $no++;
    }
    ?>
    </tbody>
  </table>

  <div class="btn-back">
    <a href='dashboard.php' class='btn btn-outline-success px-4 py-2'>&larr; Kembali ke Beranda</a>
  </div>
</div>

</body>
</html>