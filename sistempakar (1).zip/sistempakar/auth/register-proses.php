<?php
session_start();
require_once __DIR__ . '/../config.php'; // gunakan config.php

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Cek apakah username sudah ada
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['error'] = 'Username sudah terdaftar';
    header('Location: ../login.php');
    exit;
}

// Insert user baru
$stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')");
$stmt->bind_param("ss", $username, $password);

if ($stmt->execute()) {
    $_SESSION['success'] = 'Registrasi berhasil, silakan login';
    header('Location: ../login.php');
    exit;
} else {
    $_SESSION['error'] = 'Terjadi kesalahan saat registrasi';
    header('Location: ../login.php');
    exit;
}