<?php
session_start();
require_once __DIR__ . '/../config.php';

// Inisialisasi counter jika belum ada
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt_time'] = time();
}

// Batasi percobaan login (misalnya 5 kali dalam 5 menit)
$max_attempts = 5;
$lockout_time = 300; // 300 detik = 5 menit

// Cek apakah user sedang diblokir
if ($_SESSION['login_attempts'] >= $max_attempts) {
    $elapsed = time() - $_SESSION['last_attempt_time'];
    if ($elapsed < $lockout_time) {
        die("Terlalu banyak percobaan login gagal. Silakan coba lagi setelah " . ($lockout_time - $elapsed) . " detik.");
    } else {
        // Reset counter setelah lockout selesai
        $_SESSION['login_attempts'] = 0;
    }
}

// Ambil input
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    $_SESSION['error'] = "Username dan password wajib diisi!";
    header("Location: ../login.php");
    exit;
}

// Query user dengan prepared statement
$stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($password, $user['password'])) {
    // Login berhasil → reset counter
    $_SESSION['login_attempts'] = 0;
    $_SESSION['login'] = true;
    $_SESSION['username'] = $user['username'];
    $_SESSION['user_id'] = $user['id'];   // penting untuk riwayat diagnosa
    $_SESSION['role'] = $user['role'];

    // Redirect sesuai role
    if ($user['role'] === 'admin') {
        header("Location: ../admin/index.php");
    } else {
        header("Location: ../dashboard.php");
    }
    exit;
} else {
    // Login gagal → tambah counter
    $_SESSION['login_attempts']++;
    $_SESSION['last_attempt_time'] = time();
    $_SESSION['error'] = "Username atau password salah!";
    header("Location: ../login.php");
    exit;
}