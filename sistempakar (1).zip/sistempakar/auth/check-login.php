<?php
// JANGAN panggil session_start di sini

if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = 'Akses ditolak! Anda tidak memiliki hak akses.';
    header('Location: ../login.php');
    exit;
}
