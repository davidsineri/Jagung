<?php
session_start();

// Kosongkan semua variabel session
session_unset();

// Hancurkan session
session_destroy();

// Redirect ke login
header("Location: ../login.php");
exit;
