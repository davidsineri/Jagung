<?php
session_start();
require_once __DIR__ . '/../php/helper.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$rules = getRulesCF();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Rule & Certainty Factor</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      min-height: 100vh;
      /* Background jagung dengan overlay hijau */
      background: 
        linear-gradient(rgba(30, 126, 52, 0.75), rgba(30, 126, 52, 0.75)),
        url('../img/bg-corn.jpg') no-repeat center center fixed;
      background-size: cover;
    }
    .panel {
      background: rgba(255, 255, 255, 0.95);
      border-radius: 12px;
      padding: 2rem;
      box-shadow: 0 6px 18px rgba(0,0,0,.25);
      max-width: 1000px;
      margin: 3rem auto;
    }
    h3 {
      color: #1e7e34;
      font-weight: 700;
    }
    .table th {
      background-color: #e8f5e9;
      color: #1e7e34;
    }
  </style>
</head>
<body>

<div class="panel">
  <h3 class="mb-4">📐 Basis Pengetahuan (Rule & Certainty Factor)</h3>

  <a href="tambah-rule.php" class="btn btn-success mb-3">+ Tambah Rule</a>

  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Bibit</th>
        <th>Gejala & CF</th>
        <th>Tips</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach ($rules as $i => $r): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><strong><?= $r['nama_bibit'] ?></strong></td>
        <td>
          <?php foreach ($r['cf_rule'] as $k => $v): ?>
            <?= $k ?> = <?= $v ?><br>
          <?php endforeach; ?>
        </td>
        <td><?= $r['tips'] ?></td>
        <td>
          <a href="edit-rule.php?i=<?= $i ?>" class="btn btn-sm btn-primary">Edit</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="alert alert-info mt-3">
    Rule dan nilai CF didefinisikan langsung di sistem (<code>helper.php</code>).
  </div>

  <!-- Tombol Kembali -->
  <a href="index.php" class="btn btn-secondary mt-3">⬅️ Kembali</a>
</div>

</body>
</html>