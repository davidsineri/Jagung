<?php
$id = $_GET['id'] ?? null;
if (!$id) {
  header('Location: index.php');
  exit;
}

include '../php/helper.php';
$rules = getRules();

$newRules = [];
foreach ($rules as $rule) {
  if ($rule['id'] != $id) {
    $newRules[] = $rule;
  }
}

saveRules($newRules);
header('Location: index.php');
exit;