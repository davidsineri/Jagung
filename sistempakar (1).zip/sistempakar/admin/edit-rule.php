<?php
session_start();
require_once __DIR__ . '/../php/helper.php';

$rules = getRulesCF();
$i = $_GET['i'];
$rule = $rules[$i];
$gejala = ['K1','K2','K3','K4','K5','K6','K7'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rule['kode'] = $_POST['kode'];
    $rule['nama_bibit'] = $_POST['nama_bibit'];
    $rule['tips'] = $_POST['tips'];

    $rule['cf_rule'] = [];
    foreach ($gejala as $k) {
        if ($_POST[$k] > 0) {
            $rule['cf_rule'][$k] = (float)$_POST[$k];
        }
    }

    // simulasi update
    header("Location: kelola-rule.php");
    exit;
}
?>

<form method="post">
<h3>Edit Rule CF</h3>

Kode <input name="kode" value="<?= $rule['kode'] ?>"><br>
Nama <input name="nama_bibit" value="<?= $rule['nama_bibit'] ?>"><br><br>

<?php foreach ($gejala as $k): ?>
<?= $k ?>:
<input type="number" step="0.1" min="0" max="1"
name="<?= $k ?>"
value="<?= $rule['cf_rule'][$k] ?? 0 ?>"><br>
<?php endforeach ?>

<br>
<textarea name="tips"><?= $rule['tips'] ?></textarea><br>
<button>Update</button>
</form>
