<?php
session_start();
require_once __DIR__ . '/../config.php';

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM users WHERE id=$id");

header("Location: kelola-user.php");
exit;
