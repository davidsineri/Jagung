<?php
session_start();
require_once __DIR__ . '/../php/helper.php';

$gejala = ['K1','K2','K3','K4','K5','K6','K7'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $rule = [
        'kode' => $_POST['kode'],
        'nama_bibit' => $_POST['nama_bibit'],
        'cf_rule' => [],
        'tips' => $_POST['tips']
    ];

    foreach ($gejala as $k) {
        if ($_POST[$k] > 0) {
            $rule['cf_rule'][$k] = (float)$_POST[$k];
        }
    }

    // 🔥 sementara hanya simulasi (belum DB)
    $_SESSION['new_rule'] = $rule;

    header("Location: kelola-rule.php");
    exit;
}
?>

<form method="post">
<h3>Tambah Rule CF</h3>

Kode Bibit <input name="kode" required><br>
Nama Bibit <input name="nama_bibit" required><br><br>

<?php foreach ($gejala as $k): ?>
<?= $k ?> (0–1):
<input type="number" step="0.1" min="0" max="1" name="<?= $k ?>" value="0"><br>
<?php endforeach ?>

<br>
Tips:<br>
<textarea name="tips"></textarea><br>

<button>Simpan</button>
</form>
