<?php
session_start();

// GUARD ADMIN
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Sistem Pakar Jagung</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            min-height: 100vh;
            /* Background jagung dengan overlay hijau */
            background: 
                linear-gradient(rgba(30, 126, 52, 0.75), rgba(30, 126, 52, 0.75)),
                url('../img/bg-corn.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }
        .container {
            background: rgba(255, 255, 255, 0.9);
            color: #2d3436;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 6px 18px rgba(0,0,0,.25);
            max-width: 700px;
        }
        h2 {
            color: #1e7e34;
            font-weight: 700;
        }
        .list-group-item {
            font-weight: 600;
            border-radius: 8px;
            margin-bottom: 8px;
        }
        .list-group-item:hover {
            background-color: #e8f5e9;
        }
    </style>
</head>
<body>

<div class="d-flex justify-content-center align-items-center min-vh-100">
    <div class="container">
        <h2 class="mb-3">🌽 Admin Panel</h2>
        <p>Selamat datang, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong></p>

        <div class="list-group mt-4">
            <a href="kelola-user.php" class="list-group-item list-group-item-action">
                👤 Kelola User
            </a>

            <a href="kelola-gejala.php" class="list-group-item list-group-item-action">
                📋 Kelola Gejala
            </a>

            <a href="rule.php" class="list-group-item list-group-item-action">
                🧠 Kelola Rule & Certainty Factor
            </a>

            <a href="../auth/logout.php" class="list-group-item list-group-item-action text-danger">
                🚪 Logout
            </a>
        </div>
    </div>
</div>

</body>
</html>