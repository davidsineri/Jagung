<?php include '../auth/check-login.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Tentang Kami - Sistem Pakar Bibit Jagung</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"/>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #2c3e50;
      min-height: 100vh;
      color: white;
      padding: 20px 0;
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 250px;
      z-index: 1000;
    }
    .sidebar h4 {
      font-weight: 600;
      margin-bottom: 2rem;
      text-align: center;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      padding: 10px 20px;
      display: block;
      transition: all 0.2s ease;
    }
    .sidebar a:hover {
      background-color: #34495e;
      border-left: 4px solid #3498db;
    }
    .sidebar a.active {
      background-color: #34495e;
      font-weight: bold;
    }
    .content {
      margin-left: 250px;
      padding: 40px;
    }
    .header-title {
      font-size: 1.5rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 1rem;
    }
    .card {
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
  <div class="container-fluid p-0">
    <div class="row g-0">

      <!-- Sidebar -->
      <div class="col-md-2 sidebar">
        <h4>Data Bibit Jagung</h4>
        <hr>
        <a href="index.php"><i class="bi bi-house-door me-2"></i> Dashboard</a>
        <a href="add-rule.php"><i class="bi bi-plus-circle me-2"></i> Tambah Bibit</a>
        <a href="symptoms.php"><i class="bi bi-list me-2"></i> Kelola Gejala</a>
        <a href="about.php" class="active"><i class="bi bi-info-circle me-2"></i> Tentang Kami</a>
        <a href="../home.html"><i class="bi bi-arrow-left me-2"></i> Kembali ke Beranda</a>
        <div class="mt-auto p-3">
          <a href="../auth/logout.php" class="text-white d-block"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </div>
      </div>

      <!-- Main Content -->
      <div class="col-md-10 content">
        <h3 class="header-title">👨‍💻 Tentang Kami</h3>

        <div class="card p-4 mb-3">
          <h5>Profil Dosen Pembimbing</h5>
          <p><strong>Nama:</strong> Yumarlin MZ, S.Kom., M.Pd., M.Kom.</p>
        </div>

        <div class="card p-4 mb-3">
          <h5>Profil Mahasiswa</h5>
          <ul>
            <li><strong>Yudhantama Pratyahara Gunawan</strong> (NIM: 24330040)</li>
            <li><strong>David Yehuda Sineri</strong> (NIM: 21330053)</li>
          </ul>
        </div>

        <div class="card p-4">
          <h5>Tentang Aplikasi</h5>
          <p>
            Sistem Pakar Rekomendasi Bibit Jagung ini dikembangkan untuk membantu petani menentukan bibit
            yang sesuai berdasarkan kondisi lingkungan seperti curah hujan, penyakit tanaman, dan ketahanan
            terhadap hama. Sistem menggunakan metode rule-based yang disusun berdasarkan data penelitian dan
            konsultasi dengan pakar pertanian.
          </p>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
