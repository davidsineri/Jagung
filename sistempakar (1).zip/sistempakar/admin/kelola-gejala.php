<?php
session_start();
require_once __DIR__ . '/../config.php';

// GUARD ADMIN
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// TAMBAH GEJALA
if (isset($_POST['tambah'])) {
    $kode = trim($_POST['kode']);
    $nama = trim($_POST['nama_gejala']);

    if ($kode !== '' && $nama !== '') {
        $stmt = $conn->prepare("INSERT INTO gejala (kode, nama_gejala) VALUES (?, ?)");
        $stmt->bind_param("ss", $kode, $nama);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: kelola-gejala.php");
    exit;
}

// AMBIL DATA GEJALA
$data = $conn->query("SELECT * FROM gejala ORDER BY kode ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Gejala - Sistem Pakar Jagung</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      min-height: 100vh;
      /* Background jagung dengan overlay hijau */
      background: 
        linear-gradient(rgba(30, 126, 52, 0.75), rgba(30, 126, 52, 0.75)),
        url('../img/bg-corn.jpg') no-repeat center center fixed;
      background-size: cover;
    }
    .panel {
      background: rgba(255, 255, 255, 0.95);
      border-radius: 12px;
      padding: 2rem;
      box-shadow: 0 6px 18px rgba(0,0,0,.25);
      max-width: 1000px;
      margin: 3rem auto;
    }
    h3 {
      color: #1e7e34;
      font-weight: 700;
    }
    .table th {
      background-color: #e8f5e9;
      color: #1e7e34;
    }
  </style>
</head>
<body>

<div class="panel">
  <h3 class="mb-4">📋 Kelola Gejala</h3>

  <!-- FORM TAMBAH -->
  <div class="card mb-4">
    <div class="card-body">
      <form method="POST" class="row g-3">
        <div class="col-md-3">
          <input type="text" name="kode" class="form-control" placeholder="Kode (K1)" required>
        </div>
        <div class="col-md-7">
          <input type="text" name="nama_gejala" class="form-control" placeholder="Nama Gejala" required>
        </div>
        <div class="col-md-2">
          <button name="tambah" class="btn btn-success w-100">Tambah</button>
        </div>
      </form>
    </div>
  </div>

  <!-- TABEL GEJALA -->
  <div class="card">
    <div class="card-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Kode</th>
            <th>Nama Gejala</th>
            <th width="100">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $data->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['kode']); ?></td>
            <td><?= htmlspecialchars($row['nama_gejala']); ?></td>
            <td>
              <a href="delete-gejala.php?id=<?= $row['id']; ?>" 
                 class="btn btn-danger btn-sm"
                 onclick="return confirm('Hapus gejala ini?')">
                 Hapus
              </a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

  <a href="index.php" class="btn btn-secondary mt-3">⬅ Kembali</a>
</div>

</body>
</html>