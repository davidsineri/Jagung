<?php
include '../php/helper.php';

$key = $_POST['key'] ?? null;
$values = $_POST['values'][$key] ?? [];

if ($key && !empty($values)) {
    $symptoms = getSymptoms();
    $symptoms[$key] = array_values(array_unique($values));
    saveSymptoms($symptoms);
}

header('Location: symptoms.php');
exit;