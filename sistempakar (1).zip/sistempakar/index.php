<?php
session_start();

// GUARD: pastikan user sudah login
if (!isset($_SESSION['login'])) {
    header("Location: ../login.php"); // kalau belum login, balik ke login
    exit;
}

// Jika role bukan admin, lempar ke dashboard umum
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php"); 
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - Sistem Pakar Jagung</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f4f6f9;
      font-family: 'Segoe UI', sans-serif;
    }
    .sidebar {
      width: 260px;
      min-height: 100vh;
      background: #1e7e34;
      position: fixed;
      color: #fff;
    }
    .sidebar h4 {
      padding: 20px;
      text-align: center;
      font-weight: 700;
      border-bottom: 1px solid rgba(255,255,255,.2);
    }
    .sidebar a {
      display: block;
      padding: 12px 20px;
      color: #fff;
      text-decoration: none;
      transition: .2s;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background: rgba(0,0,0,.2);
      padding-left: 30px;
    }
    .content {
      margin-left: 260px;
      padding: 30px;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(0,0,0,.08);
    }
  </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
  <h4>🌽 Admin Jagung</h4>
  <a class="active" href="index.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
  <a href="users.php"><i class="bi bi-people me-2"></i>Kelola User</a>
  <a href="gejala.php"><i class="bi bi-list-check me-2"></i>Kelola Gejala</a>
  <a href="add-rule.php"><i class="bi bi-diagram-3 me-2"></i>Rule & CF</a>
  <a href="../dashboard.php"><i class="bi bi-house me-2"></i>Beranda</a>
  <a href="../auth/logout.php" class="mt-4 text-warning">
    <i class="bi bi-box-arrow-right me-2"></i>Logout
  </a>
</div>

<!-- CONTENT -->
<div class="content">
  <h3 class="fw-bold mb-4">Dashboard Admin</h3>

  <div class="row g-4">
    <div class="col-md-4">
      <div class="card p-4 text-center">
        <i class="bi bi-people fs-1 text-success"></i>
        <h5 class="mt-2">Data User</h5>
        <p class="text-muted">Kelola akun petani & admin</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card p-4 text-center">
        <i class="bi bi-list-check fs-1 text-primary"></i>
        <h5 class="mt-2">Data Gejala</h5>
        <p class="text-muted">Input gejala lingkungan</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card p-4 text-center">
        <i class="bi bi-diagram-3 fs-1 text-warning"></i>
        <h5 class="mt-2">Rule CF</h5>
        <p class="text-muted">Aturan Certainty Factor</p>
      </div>
    </div>
  </div>

  <div class="card mt-5 p-4">
    <h5>👋 Selamat Datang, <?= htmlspecialchars($_SESSION['username']) ?></h5>
    <p class="mb-0">
      Anda masuk sebagai <b>Admin</b>.  
      Gunakan menu di samping untuk mengelola sistem pakar rekomendasi bibit jagung.
    </p>
  </div>
</div>

</body>
</html>